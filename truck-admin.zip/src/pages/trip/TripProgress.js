import React from 'react'

export default function TripProgress({ data }) {
  return (
    <div>
      {Object.entries(data).map(([{ k, v }]) => {
        console.log({ k, v });
        return (
          <li key={k}>{v}</li>
        )
      })}
    </div>
  )
}
